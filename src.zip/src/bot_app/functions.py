
def retrieveWeekEventsData(jsonString):
    response = ""
    for i in jsonString:
        for item in jsonString[f"{i}"]:
            if (len(item) == 0): break
            response += f"*Мероприятие:* _{item['id']}_"
            response += f"*\nНазвание:* _{item['name']}_"
            response += f"*\nМесто:* _{item['place']}_\n"
            response += f"*Категория:* _{item['category']}_\n\n"
    return response


def retrieveDayEventData(jsonString):
    response = ""
    for event in jsonString:
        response += f"\n*Название:* _{event['name']}_"
        response += f"\n*Место:* _{event['place']}_\n"
        response += f"*Категория:* _{event['category']}_\n\n"
    return response
