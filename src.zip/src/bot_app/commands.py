from aiogram import types
from aiogram.types import message
from . import messages
from .app import dp, bot
from . data_fetcher import get_week_events, get_day_events, register_user_func, login_and_get_token, post_request_status, get_user_info
from . keyboards import inline_kb
from aiogram import Bot
import datetime
import telegram
from telegram.constants import ParseMode
from . functions import *




@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.reply(messages.WELCOME_MESSAGE, parse_mode=telegram.constants.ParseMode.MARKDOWN)


# events + username

@dp.message_handler(commands=['events'])
async def get_date(message: types.Message):
    try:
        username = register_user_and_assign_token.curr_userName
        get_date.prohibit_registration = True
    except:
        await message.reply('Просматривать мероприятия могут только *зарегистрированные* пользователи.', parse_mode=telegram.constants.ParseMode.MARKDOWN)
    else:
        try:
            res = message.text.split(' ')
            if (len(res) != 2):
                raise Exception
            else:
                get_date.date = datetime.datetime.strptime(f'{res[1]}', '%d-%m-%Y').strftime('%d-%m-%Y')
                await message.reply('Что показать?', reply_markup=inline_kb)
        except Exception:
                    await message.reply('Не корректный формат, попробуйте ввести ещё раз')



@dp.callback_query_handler(lambda c: c.data in ['Week events', 'Day events'])
async def buttom_click_call_back(callback_query: types.CallbackQuery):

    await bot.answer_callback_query(callback_query.id)
    answer = callback_query.data
        
    token =  register_user_and_assign_token.userName_token[register_user_and_assign_token.curr_userName]


    if (answer == 'Week events'):    
        jsonString = await get_week_events(get_date.date, token)
        text = retrieveWeekEventsData(jsonString)
        if (text == ""):
            await bot.send_message(callback_query.from_user.id, "На эту дату ничего не запланировано.")
        else: 
            await bot.send_message(callback_query.from_user.id, text, parse_mode=telegram.constants.ParseMode.MARKDOWN)
    elif (answer == "Day events"):  
        jsonString = await get_day_events(get_date.date, token)
        text= retrieveDayEventData(jsonString)
        if (text == ""):
            await bot.send_message(callback_query.from_user.id, "На эту дату ничего не запланировано.", parse_mode=telegram.constants.ParseMode.MARKDOWN)
        else: 
            await bot.send_message(callback_query.from_user.id, text, parse_mode=telegram.constants.ParseMode.MARKDOWN)



# пользовтель заходит и сразу авторизуется - уме возвращается token, который он может использовать, чтобы делать запросы
@dp.message_handler(commands=['register'])
async def register_user_and_assign_token(message: types.Message):
    try:
        get_date.prohibit_registration
        await message.reply("*can't register twice!*", parse_mode=telegram.constants.ParseMode.MARKDOWN)
    except AttributeError:
            try: 
                util.flag
            except AttributeError:
                user_data = message.text.split()
                if (len(user_data) != 3):
                    await message.reply("wrong data provided", parse_mode=telegram.constants.ParseMode.MARKDOWN)
                else:
                    res = await register_user_func(user_data[1], user_data[2])
                    if (res.get('password') != None):
                        await message.reply('This password is too short. It must contain at least 8 characters.', parse_mode=telegram.constants.ParseMode.MARKDOWN)
                    elif (res.get('username') != None and res.get('id') == None):
                        await message.reply('A user with that username already exists.', parse_mode=telegram.constants.ParseMode.MARKDOWN)
                    elif (res.get('username') != None and res.get('id') != None):
                        await message.reply(f'*{user_data[1]} was registered*', parse_mode=telegram.constants.ParseMode.MARKDOWN)
                        
                        # в поле я тожен сохранить is_staf - true либо false (реализовать отдельные запрос - вывод инфы о юзере)
                        register_user_and_assign_token.userName_token = { user_data[1]: (await login_and_get_token(user_data[1], user_data[2]))['auth_token']}
                        register_user_and_assign_token.curr_userName = user_data[1]
                        util(False)
            else:
                await message.reply("*can't register twice!*", parse_mode=telegram.constants.ParseMode.MARKDOWN)


def util(val):
     util.flag = val

# надо реализовать login method

    
# админ не регается он уже есть в базе он делает login
@dp.message_handler(commands=['login'])
async def login(message: types.Message):
    print(await get_user_info())
    data = message.text.split(' ')
    if (len(data) != 3):
        await message.reply("*Incorrect format*", parse_mode=telegram.constants.ParseMode.MARKDOWN)
    else:
        if ("auth_token" in (await post_request_status(data[1], data[2]))):
            login.token = (await login_and_get_token(data[1], data[2]))['auth_token']
            await message.reply(await get_user_info(login.token))
            await message.reply(f"*Success! You logged in*", parse_mode=telegram.constants.ParseMode.MARKDOWN)
        else:
            await message.reply("*Incorrect login password*", parse_mode=telegram.constants.ParseMode.MARKDOWN)
            

 


# получаю инфу от пользователя  
# @dp.message_handler(commands=['addtogroup'])
# async def register_user_and_assign_token(message: types.Message):
    

