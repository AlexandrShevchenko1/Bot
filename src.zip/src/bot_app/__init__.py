import logging
from . app import dp
from . import commands, time_table

logging.basicConfig(level=logging.INFO)

