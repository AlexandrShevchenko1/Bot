API_KEY = "6157472072:AAHFbAuPEgLvUAa82-PyqTwRX8GrhGBLZfA"
WEEK_EVENTS_URL = "http://127.0.0.1:8000/api/v1/week/"
DAY_EVENTS_URL = "http://127.0.0.1:8000/api/v1/day/"
REGISTER_USER_URL = "http://127.0.0.1:8000/api/v1/users/"
LOGIN_USER_URL = 'http://127.0.0.1:8000/api/v1/token/login/'
USER_INFO_URL = 'http://127.0.0.1:8000/api/v1/users/me/'