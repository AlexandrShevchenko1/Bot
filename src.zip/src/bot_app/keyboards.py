from aiogram.types import KeyboardButton, ReplyKeyboardMarkup, InlineKeyboardButton, InlineKeyboardMarkup

inline_button_week_events = InlineKeyboardButton("Week events", callback_data="Week events")
inline_button_day_events = InlineKeyboardButton("Day events", callback_data="Day events")
inline_kb = InlineKeyboardMarkup()

inline_kb.add(inline_button_week_events)
inline_kb.add(inline_button_day_events)